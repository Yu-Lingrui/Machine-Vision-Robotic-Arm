from enum import Enum


class MoveType(Enum):
    MOVL = 0
    MOVJ = 1


class Axis(Enum):
    X = 0
    Y = 1
    Z = 2
    R = 3
