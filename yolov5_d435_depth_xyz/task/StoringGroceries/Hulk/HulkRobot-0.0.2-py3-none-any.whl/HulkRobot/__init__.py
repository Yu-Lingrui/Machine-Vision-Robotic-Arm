import socket  # 导入 socket 模块
from HulkRobot.HulkEnum import *
from HulkRobot.HulkEvent import *
from threading import Thread
import re
import base64

EVENT_CONNECTED = "Event_Connect"
EVENT_DISCONNECTED = "Event_Disconnect"
EVENT_ROBOT = "Event_robot"


class HulkRobot:
    g_socket_server = None  # 负责监听的socket
    g_conn_pool = []  # 连接池
    bServerOpen = False
    __server_ip__ = ""
    __encryption__ = False

    def __init__(self, event_manager):
        self.__eventManager = event_manager

    def open_server(self):
        """
        打开服务端
        """
        # self.__server_ip__ = HulkRobot.__GetLocalIPByPrefix("192.168.43")
        self.__server_ip__ = "192.168.10.102"
        # print("server:"+server_ip)
        if self.bServerOpen:
            print("Server Opened")
            return False
        else:
            if self.__server_ip__ == '':
                print("Server IP Error")
                return False
            self.g_socket_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # 创建 socket 对象
            # host = socket.gethostname()
            server_addr = (self.__server_ip__, 8080)  # 绑定地址
            self.g_socket_server.bind(server_addr)
            self.g_socket_server.listen(5)  # 最大等待数（有很多人理解为最大连接数，其实是错误的）
            self.bServerOpen = True
            print("Server has been opened,waiting for client...")
            thread = Thread(target=HulkRobot.__accept_client, args=(self,))
            thread.setDaemon(True)
            thread.start()
            return True

    def close_server(self):
        """
        关闭服务端
        """
        # g_socket_server.shutdown(socket.SHUT_RDWR)
        if self.bServerOpen:
            self.bServerOpen = False
            self.g_socket_server.close()
            print("Server open:", self.bServerOpen)

    def __accept_client(self):
        """
        接收新连接
        """
        while self.bServerOpen:
            # print("Server open:", self.bServerOpen)
            try:
                client, _ = self.g_socket_server.accept()  # 阻塞，等待客户端连接
                # print(client.getpeername(), " connected......")
                # 加入连接池
                self.g_conn_pool.append(client)
                # 给每个客户端创建一个独立的线程进行管理
                thread = Thread(target=HulkRobot.message_handle, args=(self, client,))
                # 设置成守护线程
                thread.setDaemon(True)
                thread.start()
                event = Event(type_=EVENT_CONNECTED)
                event.dict["ClientID"] = client.getpeername()
                self.__eventManager.SendEvent(event)  # 发送事件
            # thread.join(3)
            except Exception as e:
                print("accpept error")

    def set_encryption(self, encryption):
        self.__encryption__ = encryption

    def message_handle(self, client):
        """
        消息处理
        """
        # client.sendall("Hello".encode(encoding='utf8'))
        while True:
            try:
                bMsg = client.recv(1024)
                # print("client msg:", client, bMsg.decode(encoding='utf8'))
                if len(bMsg) == 0:
                    event = Event(type_=EVENT_DISCONNECTED)
                    event.dict["ClientID"] = client.getpeername()
                    self.__eventManager.SendEvent(event)  # 发送事件
                    client.close()
                    # 删除连接
                    self.g_conn_pool.remove(client)
                # print("Client disconnected")
                    break
                else:
                    msg = bMsg.decode(encoding='utf8')
                    msg = msg.strip()
                    if msg.startswith('#%') and msg.endswith('%#'):
                      self.__data_analysis(bMsg.decode(encoding='utf8'))
            except (ConnectionResetError, OSError):
                event = Event(type_=EVENT_DISCONNECTED)
                event.dict["ClientID"] = self.g_conn_pool[0].getpeername()
                self.__eventManager.SendEvent(event)  # 发送事件
                self.g_conn_pool[0].close()
                # 删除连接
                del self.g_conn_pool[0]
                break

    def get_connected_robot(self):
        if self.bServerOpen and len(self.g_conn_pool) > 0:
            return self.g_conn_pool[0].getpeername()
        else:
            return ''

    def scan(self):
        if self.bServerOpen:
            __tcp_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                __tcp_client.connect(('192.168.10.101', 8081))
                # hostname = socket.gethostname()
                # ipaddr = socket.gethostbyname(hostname)
                # __tcp_client.connect(('127.0.0.1', 8081))
                s = 'Robot Server:{0},8080'.format(self.__server_ip__)
                if self.__encryption__:
                    s = str(base64.b64encode(s.encode('utf-8')), 'utf8')
                msg = '#%'+s+'%#'
                __tcp_client.send(msg.encode(encoding='utf8'))
            except socket.error:
                print("faild to find robot")
                return False
            return True
        else:
            print("Please open server first")
            return False

    def send_msg(self, msg):
        if self.bServerOpen and len(self.g_conn_pool) > 0:
            if self.__encryption__:
                msg = str(base64.b64encode(msg.encode('utf-8')), 'utf8')
            msg = "#%" + msg + "%#"
            try:
                self.g_conn_pool[0].sendall(msg.encode(encoding='utf8'))
                # if not 'Inquire:' in msg:
                #     print("send ", msg)
            except (ConnectionResetError, OSError):
                self.g_conn_pool[0].close()
                event = Event(type_=EVENT_DISCONNECTED)
                event.dict["ClientID"] = self.g_conn_pool[0].getpeername()
                self.__eventManager.SendEvent(event)  # 发送事件
                # 删除连接
                del self.g_conn_pool.remove[0]

    def enable(self, is_enable):
        msg = 'Setenable:{0}'.format(0)
        if is_enable:
            msg = 'Setenable:{0}'.format(1)
        # msg = "#%"+msg+"#%"
        self.send_msg(msg)

    def online(self, is_online):
        msg = 'Ronlinesta:{0}'.format(0)
        if is_online:
            msg = 'Ronlinesta:{0}'.format(1)
        # msg = "#%" + msg + "#%"
        self.send_msg(msg)

    @staticmethod
    def __str2bool(str):
        return True if str.lower() == 'true' else False

    def reset(self):
        msg = 'Reset:0,1'
        self.send_msg(msg)

    def move(self, move_type, x, y, z, r, speed, acc):
        msg = '{0},{1},{2},{3},{4},{5}'.format(x, y, z, r, speed, acc)
        if move_type == MoveType.MOVL:
            msg = 'Mov:MOVL,'+msg
        else:
            msg = 'Mov:MOVJ,'+msg
        self.send_msg(msg)

    def set_io(self, io):
        msg = 'SetIO:{0}'.format(io)
        self.send_msg(msg)

    def move_single(self, axis, delta):
        key = 1
        if axis == Axis.X:
            key = 1
        elif axis == Axis.Y:
            key = 3
        elif axis == Axis.Z:
            key = 5
        elif axis == Axis.R:
            key = 7
        if delta < 0:
            key += 1
        msg = 'KeyValue:{0},{1}'.format(key, abs(delta))
        self.send_msg(msg)

    def request_coord(self):
        msg = "Inquire:"
        self.send_msg(msg)

    def __data_analysis(self, msg):
        data = msg.strip('#%')
        if self.__encryption__:
            try:
                data = str(base64.b64decode(data), 'utf8')
            except Exception as e:
                print('消息错误')
        # print('data analysis:', data)
        event = Event(type_=EVENT_ROBOT)
        data_array = data.split(':', 1)
        if len(data_array) == 1:
            event.dict["type"] = data_array[0]
            event.dict["content"] = ""
        elif len(data_array) >= 2:
            event.dict["type"] = HulkRobot.__get_type(data_array[0])
            event.dict["content"] = HulkRobot.__find_number(data_array[1])
        else:
            return
        self.__eventManager.SendEvent(event)  # 发送事件

    @staticmethod
    def __get_type(t):
        if t == 'Ackm':
            return 'Basic'
        else:
            return t

    """
    @staticmethod
    def __get_content(t, c):
        if t == 'Ackm':
            return 'Basic'
        else:
            return t
    """

    @staticmethod
    def __find_number(c):
        result = re.findall(r'\d+', c)
        return result

    @staticmethod
    def __GetLocalIPByPrefix(prefix):
        localIP = ""
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            if ip.startswith(prefix):
                localIP = ip
                break
        print(localIP)
        return localIP
